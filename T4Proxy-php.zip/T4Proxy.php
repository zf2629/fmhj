<?php
// ============================================================================
// Spider API - Type 4 风格代理 (PHP版 - 内置服务器版)
// ============================================================================

define('SPIDER_API_HOST', 'http://127.0.0.1:9978');
define('DEFAULT_SITE_KEY', '');
define('REQUEST_TIMEOUT', 30);

// ============================================================================
// Spider API 客户端
// ============================================================================
class SpiderApiClient
{
    private $host;
    private $timeout;

    public function __construct($host, $timeout = 30)
    {
        $this->host = rtrim($host, '/');
        $this->timeout = $timeout;
    }

    public function configAction($action, $extra = [])
    {
        return $this->post('/spider/config', array_merge(['action' => $action], $extra));
    }

    public function execute($key, $method, $params = [])
    {
        return $this->post('/spider', array_merge(['key' => $key, 'method' => $method], $params));
    }

    public function homeContent($key, $filter = true)
    {
        return $this->execute($key, 'homeContent', ['filter' => $filter]);
    }

    public function categoryContent($key, $tid, $page = 1, $filter = true, $extend = [])
    {
        return $this->execute($key, 'categoryContent', [
            'tid' => $tid, 'pg' => $page, 'filter' => $filter, 'extend' => $extend
        ]);
    }

    public function detailContent($key, $ids)
    {
        return $this->execute($key, 'detailContent', ['ids' => is_array($ids) ? $ids : [$ids]]);
    }

    public function searchContent($key, $keyword, $page = 1)
    {
        return $this->execute($key, 'searchContent', ['wd' => $keyword, 'pg' => $page]);
    }

    public function playerContent($key, $flag, $id, $flags = [])
    {
        return $this->execute($key, 'playerContent', ['flag' => $flag, 'id' => $id, 'flags' => $flags]);
    }

    private function post($endpoint, $data)
    {
        $url = $this->host . $endpoint;
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data, JSON_UNESCAPED_UNICODE),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json; charset=utf-8'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($errno) {
            return ['code' => -1, 'msg' => "Request failed: {$error}"];
        }
        
        $result = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return ['code' => -1, 'msg' => 'Invalid JSON response'];
        }
        
        return $result;
    }
}

// ============================================================================
// Type 4 代理
// ============================================================================
class SpiderApiProxy
{
    private $client;
    private $defaultKey;

    public function __construct($client, $defaultKey = '')
    {
        $this->client = $client;
        $this->defaultKey = $defaultKey;
    }

    public function handle()
    {
        header('Content-Type: application/json; charset=utf-8');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');

        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(204);
            exit;
        }

        try {
            $result = $this->dispatch();
            echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        } catch (Exception $e) {
            echo json_encode(['error' => $e->getMessage()], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
    }

    private function dispatch()
    {
        $input = $this->getInput();
        
        // 从 PATH_INFO 获取 key
        $key = $this->getKeyFromPath();
        if (empty($key)) {
            $key = isset($input['key']) ? $input['key'] : $this->defaultKey;
        }

        // 兼容处理：play 参数作为 id 的别名
        if (isset($input['play']) && !isset($input['id'])) {
            $input['id'] = $input['play'];
        }

        // 根据参数特征判断接口类型
        $ac = '';
        
        if (isset($input['wd']) && !empty($input['wd'])) {
            // 搜索接口
            $ac = 'search';
        } elseif (isset($input['t']) && !empty($input['t'])) {
            // 有 t 参数就是分类列表
            $ac = 'list';
        } elseif (isset($input['ids']) && !empty($input['ids'])) {
            // 有 ids 参数就是详情
            $ac = 'detail';
        } elseif (isset($input['flag']) && !empty($input['flag']) && isset($input['id']) && !empty($input['id'])) {
            // 有 flag 和 id 就是播放
            $ac = 'play';
        } elseif (empty($key) || $key === 'config' || (isset($input['ac']) && $input['ac'] === 'config')) {
            // 配置接口
            $ac = 'config';
        } else {
            // 默认是首页/列表
            $ac = 'list';
        }

        // 处理配置接口
        if ($ac === 'config') {
            return $this->getProxiedConfig();
        }

        // 验证 key
        if (empty($key)) {
            return ['error' => '缺少 key 参数'];
        }

        // 调用 Spider API
        $apiResult = null;
        $pg = isset($input['pg']) ? (int)$input['pg'] : 1;

        // 路由分发
        switch ($ac) {
            case 'search':
                $apiResult = $this->client->searchContent($key, $input['wd'], $pg);
                break;

            case 'detail':
                $ids = is_array($input['ids']) ? $input['ids'] : explode(',', $input['ids']);
                $apiResult = $this->client->detailContent($key, $ids);
                break;

            case 'play':
                $flags = isset($input['flags']) ? explode(',', $input['flags']) : [];
                $apiResult = $this->client->playerContent($key, $input['flag'], $input['id'], $flags);
                // 播放接口直接返回原始数据，不需要格式化
                if ($apiResult && isset($apiResult['code']) && $apiResult['code'] === 0) {
                    return isset($apiResult['data']) ? $apiResult['data'] : $apiResult;
                }
                return ['error' => isset($apiResult['msg']) ? $apiResult['msg'] : '请求失败'];

            case 'list':
            default:
                $t = isset($input['t']) ? $input['t'] : '';
                $filter = !isset($input['f']) || $input['f'] === '1';

                if (empty($t)) {
                    $apiResult = $this->client->homeContent($key, $filter);
                } else {
                    $extend = [];
                    foreach (['area', 'year', 'type', 'class', 'lang'] as $field) {
                        if (isset($input[$field]) && !empty($input[$field])) {
                            $extend[$field] = $input[$field];
                        }
                    }
                    $apiResult = $this->client->categoryContent($key, $t, $pg, $filter, $extend);
                }
                break;
        }

        // 返回苹果CMS标准格式
        if ($apiResult && isset($apiResult['code']) && $apiResult['code'] === 0) {
            return $this->formatMacCmsResponse($apiResult['data'], $pg);
        }

        // 错误情况
        return ['error' => isset($apiResult['msg']) ? $apiResult['msg'] : '请求失败'];
    }

    private function getKeyFromPath()
    {
        $pathname = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        
        // 移除查询字符串
        if (($pos = strpos($pathname, '?')) !== false) {
            $pathname = substr($pathname, 0, $pos);
        }
        
        // 分割路径
        $pathParts = explode('/', trim($pathname, '/'));
        $pathParts = array_filter($pathParts);
        
        // 如果有路径段，返回第一个（假设是 key），并进行 URL 解码
        if (!empty($pathParts)) {
            try {
                return urldecode($pathParts[0]);
            } catch (Exception $e) {
                return $pathParts[0];
            }
        }
        return '';
    }

    private function formatMacCmsResponse($data, $currentPage = 1)
    {
        // 获取 list
        $list = isset($data['list']) ? $data['list'] : [];
        $listCount = count($list);

        // 从返回数据中获取或动态计算
        $page = isset($data['page']) ? (int)$data['page'] : $currentPage;
        $limit = isset($data['limit']) ? (int)$data['limit'] : ($listCount > 0 ? $listCount : 20);

        // 计算总页数：优先使用返回值，否则写死 9999
        $pagecount = isset($data['pagecount']) ? (int)$data['pagecount'] : 9999;

        // 计算总数：优先使用返回值，否则用 pagecount * limit
        $total = isset($data['total']) ? (int)$data['total'] : $pagecount * $limit;

        // 苹果CMS标准返回格式
        $response = [
            'page' => $page,
            'pagecount' => $pagecount,
            'limit' => $limit,
            'total' => $total,
            'list' => $list
        ];

        if (isset($data['class'])) {
            $response['class'] = $data['class'];
        }
        if (isset($data['filters'])) {
            $response['filters'] = $data['filters'];
        }

        return $response;
    }

    private function getProxiedConfig()
    {
        $status = $this->client->configAction('status');
        
        if (!isset($status['code']) || $status['code'] !== 0 || empty($status['data']['sites'])) {
            return ['error' => '获取配置失败'];
        }

        $sites = $status['data']['sites'];
        $baseUrl = $this->getBaseUrl();

        $config = [
            'spider' => '',
            'wallpaper' => 'https://深色壁纸.xxooo.cf/',
            'warningText' => '资源来自网络，仅供学习使用',
            'sites' => [],
            'doh' => $this->getDefaultDoh(),
            'rules' => $this->getDefaultRules(),
            'lives' => []
        ];

        foreach ($sites as $site) {
            $config['sites'][] = [
                'key' => $site['key'],
                'name' => $site['name'],
                'api' => $baseUrl . '/' . $site['key'],
                'type' => '4',
                'searchable' => isset($site['searchable']) ? (int)$site['searchable'] : 1,
                'quickSearch' => isset($site['quickSearch']) ? (int)$site['quickSearch'] : 1,
                'filterable' => isset($site['filterable']) ? (int)$site['filterable'] : 1,
            ];
        }

        return $config;
    }

    private function getBaseUrl()
    {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
        
        // 如果有端口号，包含端口（但注意不要重复添加）
        if (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] != 80 && $_SERVER['SERVER_PORT'] != 443) {
            // 如果 HTTP_HOST 已经包含端口，就不再添加
            if (strpos($host, ':') === false) {
                $host .= ':' . $_SERVER['SERVER_PORT'];
            }
        }
        
        // 对于 PHP 内置服务器，SCRIPT_NAME 可能为空
        $script = isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '/T4Proxy.php';
        
        // 移除可能的多余斜杠
        $baseUrl = $protocol . '://' . $host;
        
        // 清理脚本路径中的多余斜杠
        $script = trim($script, '/');
        if (!empty($script)) {
            $baseUrl .= '/' . $script;
        }
        
        return rtrim($baseUrl, '/');
    }

    private function getDefaultDoh()
    {
        return [
            ['name' => 'Google', 'url' => 'https://dns.google/dns-query', 'ips' => ['8.8.4.4', '8.8.8.8']],
            ['name' => 'Cloudflare', 'url' => 'https://cloudflare-dns.com/dns-query', 'ips' => ['1.1.1.1', '1.0.0.1']],
        ];
    }

    private function getDefaultRules()
    {
        return [
            ['name' => 'lz', 'hosts' => ['vip.lz', 'hd.lz'], 'regex' => ['18.5333']],
            ['name' => '非凡', 'hosts' => ['vip.ffzy', 'hd.ffzy'], 'regex' => ['25.0666']],
        ];
    }

    private function getInput()
    {
        $input = array_merge($_GET, $_POST);
        
        // 对查询参数进行 URL 解码
        foreach ($input as $key => $value) {
            if (is_string($value)) {
                $input[$key] = urldecode($value);
            }
        }
        
        $rawBody = file_get_contents('php://input');
        if (!empty($rawBody)) {
            $jsonBody = json_decode($rawBody, true);
            if (is_array($jsonBody)) {
                $input = array_merge($input, $jsonBody);
            }
        }
        return $input;
    }
}

// ============================================================================
// 启动信息显示（仅 CLI 模式）
// ============================================================================
if (php_sapi_name() === 'cli') {
    echo "===========================================\n";
    echo "Spider API Type 4 代理服务器\n";
    echo "===========================================\n\n";
    
    // 显示局域网 IP
    if (function_exists('shell_exec')) {
        $ips = [];
        // 尝试获取 IP 地址
        if (strtoupper(substr(PHP_OS, 0, 3)) !== 'WIN') {
            $output = shell_exec("ip addr show 2>/dev/null || ifconfig 2>/dev/null");
            if (preg_match_all('/inet (\d+\.\d+\.\d+\.\d+)/', $output, $matches)) {
                foreach ($matches[1] as $ip) {
                    if ($ip !== '127.0.0.1' && $ip !== '0.0.0.0') {
                        $ips[] = $ip;
                    }
                }
            }
        }
        
        echo "服务器已启动:\n";
        echo "本地地址: http://localhost:10999\n";
        if (!empty($ips)) {
            foreach ($ips as $ip) {
                echo "局域网地址: http://{$ip}:10999\n";
            }
        }
    }
    
    echo "\n访问示例:\n";
    echo "配置接口: http://localhost:10999?ac=config\n";
    echo "首页接口: http://localhost:10999/站源key\n";
    echo "搜索接口: http://localhost:10999/站源key?wd=关键词\n";
    echo "详情接口: http://localhost:10999/站源key?ids=视频ID\n";
    echo "播放接口: http://localhost:10999/站源key?flag=播放源&id=播放ID\n";
    echo "            或: http://localhost:10999/站源key?flag=播放源&play=播放ID\n\n";
    
    echo "提示: ac参数可省略，系统会根据其他参数自动识别接口类型\n";
    echo "筛选参数: area=地区&year=年份&type=类型&class=剧情&lang=语言\n";
    echo "\n按 Ctrl+C 停止服务器\n";
    echo "===========================================\n\n";
}

// ============================================================================
// 主入口
// ============================================================================
$client = new SpiderApiClient(SPIDER_API_HOST, REQUEST_TIMEOUT);
$proxy = new SpiderApiProxy($client, DEFAULT_SITE_KEY);
$proxy->handle();